using PROG6221_POE_PART_TWO;

namespace TestCalorieCalculation
{
    //CODE ATTRIBUTION
    //UNIT TESTS
    //AUTHOR: Cesar Aguirre 
    //SOURCE:https://exceptionnotfound.net/unit-testing-101-write-your-first-unit-test-in-csharp-with-mstest/
    //DATE ACCESSED: 30 MAY 2024

    [TestClass]
    public class UnitTest1
    {
        public bool eventTriggered;
        public string? eventRecipeName;
        public double eventTotalCalories;

        [TestInitialize]
        public void TestInitialize()
        {
            eventTriggered = false;
            eventRecipeName = string.Empty;
            eventTotalCalories = 0.0;
        }

        public void OnRecipeCaloriesExceeded(string recipeName, double totalCalories)
        {
            eventTriggered = true;
            eventRecipeName = recipeName;
            eventTotalCalories = totalCalories;
        }

        [TestMethod]
        public void TestCalculateTotalCalories_Under300()
        {
         
            Recipe testRecipe = new Recipe { recipeName = "Test Low Calorie Recipe" };
            testRecipe.AddIngredient(new Ingredient { Name = "Ingredient 1", Calories = 120 });
            testRecipe.AddIngredient(new Ingredient { Name = "Ingredient 2", Calories = 75 });
            testRecipe.AddIngredient(new Ingredient { Name = "Ingredient 3", Calories = 15 });
               double totalCalories = testRecipe.CalculateTotalCalories();

            Assert.AreEqual(210, totalCalories);
        }


        [TestMethod]
        public void TestCalculateTotalCalories_Above300Calories()
        {
            // Arrange
            Recipe testRecipe = new Recipe { recipeName = "Test High Calorie Recipe" };
            testRecipe.RecipeCaloriesExceeded += OnRecipeCaloriesExceeded;
            testRecipe.AddIngredient(new Ingredient { Name = "Ingredient 1", Calories = 300 });
            testRecipe.AddIngredient(new Ingredient { Name = "Ingredient 2", Calories = 150 });


            double totalCalories = testRecipe.CalculateTotalCalories();

            Assert.IsTrue(eventTriggered);
            Assert.AreEqual(450, totalCalories);

            //testing it returna the correct recipe name
            Assert.AreEqual("Test High Calorie Recipe", eventRecipeName);

            Assert.AreEqual(450, eventTotalCalories);
        }

        [TestMethod]
        public void TestCalculateTotalCalories_NoIngredientsAddedYet()
        {

            Recipe testRecipe = new Recipe { recipeName = "Test Recipe" };

            double totalCalories = testRecipe.CalculateTotalCalories();

            Assert.AreEqual(0, totalCalories);
        }




        [TestMethod]
        public void TestCalculateTotalCalories_ZeroCalories()
        {
            
            Recipe testRecipe = new Recipe { recipeName = "Zero Calorie Recipe" };
            testRecipe.AddIngredient(new Ingredient { Name = "Water", Calories = 0 });
            testRecipe.AddIngredient(new Ingredient { Name = "Ice", Calories = 0 });
double totalCalories = testRecipe.CalculateTotalCalories();

            Assert.AreEqual(0, totalCalories);
        }

     

      

    }
}